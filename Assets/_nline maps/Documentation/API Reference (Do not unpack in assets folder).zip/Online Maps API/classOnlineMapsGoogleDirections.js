var classOnlineMapsGoogleDirections =
[
    [ "Params", "classOnlineMapsGoogleDirections_1_1Params.html", "classOnlineMapsGoogleDirections_1_1Params" ],
    [ "Avoid", "classOnlineMapsGoogleDirections.html#add9ee8192851ee3ccbe8566211314f79", [
      [ "none", "classOnlineMapsGoogleDirections.html#add9ee8192851ee3ccbe8566211314f79a334c4a4c42fdb79d7ebc3e73b517e6f8", null ],
      [ "tolls", "classOnlineMapsGoogleDirections.html#add9ee8192851ee3ccbe8566211314f79a688e46effdf049725c7b7ccff16b14f3", null ],
      [ "highways", "classOnlineMapsGoogleDirections.html#add9ee8192851ee3ccbe8566211314f79a42de9cd92164ca7e1c8c6b1c06384acc", null ],
      [ "ferries", "classOnlineMapsGoogleDirections.html#add9ee8192851ee3ccbe8566211314f79a663cef2817f3ca967115b48c414fc859", null ]
    ] ],
    [ "Mode", "classOnlineMapsGoogleDirections.html#ab3045cc0fe3ecb941c0cc14300301ea0", [
      [ "driving", "classOnlineMapsGoogleDirections.html#ab3045cc0fe3ecb941c0cc14300301ea0acc32ac19011c3d3d2fabf488f7f56467", null ],
      [ "walking", "classOnlineMapsGoogleDirections.html#ab3045cc0fe3ecb941c0cc14300301ea0a099410f601830a2873dd98ea0acf711d", null ],
      [ "bicycling", "classOnlineMapsGoogleDirections.html#ab3045cc0fe3ecb941c0cc14300301ea0a7a0fc9ec6bc0e50bd561deb9e1a172c8", null ],
      [ "transit", "classOnlineMapsGoogleDirections.html#ab3045cc0fe3ecb941c0cc14300301ea0adcef234a574fa354c82127c50b83174a", null ]
    ] ],
    [ "TrafficModel", "classOnlineMapsGoogleDirections.html#a072c03875de9435bb48ab983c5407cda", [
      [ "bestGuess", "classOnlineMapsGoogleDirections.html#a072c03875de9435bb48ab983c5407cdaae7c19d13bd2f5f6766eeb1eefadf2421", null ],
      [ "pessimistic", "classOnlineMapsGoogleDirections.html#a072c03875de9435bb48ab983c5407cdaa70c80cb25b21e8bac39f4be0cf902626", null ],
      [ "optimistic", "classOnlineMapsGoogleDirections.html#a072c03875de9435bb48ab983c5407cdaa9a0d734a8cc94890376ad2b82e3771e3", null ]
    ] ],
    [ "TransitMode", "classOnlineMapsGoogleDirections.html#ab83cef0e0b693f7916bb541d5c8481ae", [
      [ "bus", "classOnlineMapsGoogleDirections.html#ab83cef0e0b693f7916bb541d5c8481aead20f83ee6933aa1ea047fe5cbd9c1fd5", null ],
      [ "subway", "classOnlineMapsGoogleDirections.html#ab83cef0e0b693f7916bb541d5c8481aeade80593878cb1673c62a7f338dc7e4e1", null ],
      [ "train", "classOnlineMapsGoogleDirections.html#ab83cef0e0b693f7916bb541d5c8481aea61b3a8faa9c1091806675c230a9abe64", null ],
      [ "tram", "classOnlineMapsGoogleDirections.html#ab83cef0e0b693f7916bb541d5c8481aeaecb1da74e8ff8fdd2911197ecf8badc0", null ],
      [ "rail", "classOnlineMapsGoogleDirections.html#ab83cef0e0b693f7916bb541d5c8481aea70036b7bb753dee338a8a6baa67e2103", null ]
    ] ],
    [ "TransitRoutingPreference", "classOnlineMapsGoogleDirections.html#ae7f3dacd329b3d56b734ed6fd1ebdc94", [
      [ "lessWalking", "classOnlineMapsGoogleDirections.html#ae7f3dacd329b3d56b734ed6fd1ebdc94adc4f526e463e5efaae116af0359a25b1", null ],
      [ "fewerTransfers", "classOnlineMapsGoogleDirections.html#ae7f3dacd329b3d56b734ed6fd1ebdc94aa0847859a0c887028a8f1e8054c2c092", null ]
    ] ],
    [ "Units", "classOnlineMapsGoogleDirections.html#a57e4ab01bb4a2bd6c18ea5869e5e0aea", [
      [ "metric", "classOnlineMapsGoogleDirections.html#a57e4ab01bb4a2bd6c18ea5869e5e0aeaa2cbc8352e68eb2a531a57d26f53c2db1", null ],
      [ "imperial", "classOnlineMapsGoogleDirections.html#a57e4ab01bb4a2bd6c18ea5869e5e0aeaa4998873ea4c18994973e7bd683cefb4f", null ]
    ] ],
    [ "OnlineMapsGoogleDirections", "classOnlineMapsGoogleDirections.html#a463e1a54ad9a1834019ffbac7ca2b305", null ],
    [ "Find", "classOnlineMapsGoogleDirections.html#abb1984bd397c6ae43e98b369976cfc04", null ],
    [ "GetResult", "classOnlineMapsGoogleDirections.html#ad29cc005c002d628b9e0cf3baac454d4", null ],
    [ "requestParams", "classOnlineMapsGoogleDirections.html#ad431f0827e113dd42459068064ec7e2d", null ]
];