var searchData=
[
  ['name_3099',['name',['../classOnlineMapsXML.html#ad1e3724a96089127623e12774d23d1cf',1,'OnlineMapsXML']]],
  ['noderefs_3100',['nodeRefs',['../classOnlineMapsOSMWay.html#aa5893ecacad115acb76a0866269f140a',1,'OnlineMapsOSMWay']]]
];
